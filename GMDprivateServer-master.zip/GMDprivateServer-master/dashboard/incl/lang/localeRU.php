<?php

/*
Alright, since shit's happening with some certain GDPS, i feel like i need to address this. 
This applies to any versions of the translation starting from the version this text first appeared in, starting from December 19, 2017.


If my (TheFox#5812's) work is used in a project that is not CvoltonGDPS, I have the full right to request my work, being the translation, removed from the project. If not done, i have full permission to fill a DMCA claim to the domain of the project.
I also have full right to request an edit to my work, if not done, as stated above, i am able to fill a DMCA claim.
If you do not agree to these terms, remove this file from the folder that it is located in.


TL;DR if you use this outside cvoltongdps i can delet your site kthxbye
 - Artemiy "TheFox" Aleksandrov Borisovich.
 - Sergey "bit0r1n" Khomich
*/

/*
	NAVBAR
*/
$string["homeNavbar"] = "Домой";

$string["accountManagement"] = "Личный кабинет";
$string["changePassword"] = "Изменить пароль";
$string["changeUsername"] = "Изменить ник";
$string["unlistedLevels"] = "Скрытые уровни";

$string["modTools"] = "Меню модератора";
$string["leaderboardBan"] = "Бан";
$string["packCreate"] = "Создать набор карт";

$string["reuploadSection"] = "Загрузить";
$string["levelReupload"] = "Уровень с другого сервера";
$string["songAdd"] = "Добавить песню";

$string["browse"] = "Списки";
$string["statsSection"] = "Статистика";
$string["dailyTable"] = "Дневные уровни";
$string["modActions"] = "Действия модераторов";
$string["packTable"] = "Все наборы карт";
$string["gauntletTable"] = "Подземелья";
$string["leaderboardTime"] = "Лидерборды";

$string["language"] = "Язык";

$string["loginHeader"] = "Привет, %s";
$string["logout"] = "Выйти";
$string["login"] = "Войти";


/*
	REUPLOAD
*/
$string["reuploadBTN"] = "Загрузка с другого сервера";
$string["errorGeneric"] = "Ошибка:";
$string["tryAgainBTN"] = "Попробовать заново";
//songAdd.php
$string["songAddUrlFieldLabel"] = "URL Песни: (Только прямые ссылки, ссылки Dropbox и ссылки Soundcloud)";
$string["songAddUrlFieldPlaceholder"] = "URL Песни";
$string["songAddAnotherBTN"] = "Загрузить ещё песню";
///errors
$string["songAddError-2"] = "Что-то не то с URL";
$string["songAddError-3"] = "Уже добавлена";
$string["songAddError-4"] = "Невозможно добавить";

/*
	STATS
*/
$string["ID"] = "ID";
$string["stars"] = "Звёзды";
$string["coins"] = "Монеты";
$string["accounts"] = "Аккаунты";
$string["levels"] = "Уровни";
$string["songs"] = "Песни";
$string["author"] = "Создатель";
$string["name"] = "Название";
$string["userCoins"] = "Серебрянные монеты";
$string["time"] = "Время";
$string["deletedLevel"] = "Удалённый уровень";
$string["mod"] = "Модератор";
$string["count"] = "Число";
$string["ratedLevels"] = "Оценнённые уровни";
$string["lastSeen"] = "Заходил в последний раз";
$string["level"] = "Уровень";
$string["pageInfo"] = "Страница %s из %s-и";
$string["first"] = "Первая";
$string["previous"] = "Предыдущая";
$string["next"] = "Следующая";
$string["last"] = "Последняя";
$string["go"] = "Перейти";
//modActionsList
$string["action"] = "Функция";
$string["value"] = "1-е значение";
$string["value2"] = "2-е значение";
$string["modAction1"] = "Оценили уровень";
$string["modAction2"] = "Убрали/добавили к Звёздным Уровням";
$string["modAction3"] = "Проверили монеты";
$string["modAction4"] = "Убрали/Добавили к Эпик Уровням";
$string["modAction5"] = "Сделали дневным уровнем";
$string["modAction6"] = "Удалили уровень";
$string["modAction7"] = "Изминили создателя";
$string["modAction8"] = "Переименовали уровень";
$string["modAction9"] = "Изменили пароль уровня";
$string["modAction10"] = "Изменили сложность уровня";
$string["modAction11"] = "Поделились CP (Очки креатора)";
$string["modAction12"] = "Опубликовали";
$string["modAction13"] = "Изменили описание";
$string["modAction14"] = "Включили/выключили ЛДМ";
$string["modAction15"] = "Бан по лидербордам";
//errors
$string["errorNoAccWithPerm"] = "Ошибка: никаких аккаунтов с возмоюностью '%s' были найдены.";

//Translation done by TheFox#5812 and bit0r1n#1707
