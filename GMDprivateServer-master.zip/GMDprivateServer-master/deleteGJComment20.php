<?php
include "incl/comments/deleteGJComment.php";
?>